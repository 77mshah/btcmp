# Number Checker

In this activity we will create a number guessing game.

## Instructions

* Using the [number-checker.html](Unsolved/number-checker.html) as a starting point, add code so that:

  * A computer picks a random number between 1 and 4.

  * Users then “click” the buttons numbered 1 – 4.

  * If the user’s number matches the computer’s number, display text informing them that they've won in the "Result" panel. Otherwise, display text informing them that they've lost.

* If you finish early, try to improve the aesthetics.
